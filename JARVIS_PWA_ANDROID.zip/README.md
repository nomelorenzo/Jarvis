# JARVIS PWA — Android

Versão instalável pelo Chrome no Samsung Galaxy A15, sem APK.

## Como usar

1. Publique esta pasta em um endereço HTTPS (GitHub Pages, Cloudflare Pages, Vercel ou outro host).
2. Abra o endereço no Chrome do Galaxy A15.
3. Permita o microfone.
4. Use **Falar com JARVIS**.
5. Use o menu do Chrome > **Adicionar à tela inicial / Instalar app**.

## Backend

Toque em **Configurar servidor** e informe o endereço do backend JARVIS 2.0, por exemplo:
`http://192.168.1.10:8000`

O backend precisa aceitar `POST /chat`.

## Comandos locais

A versão PWA pode abrir links de apps conhecidos e pesquisar jogos na Play Store. Ela não instala apps silenciosamente e não executa comandos arbitrários no Android.

## Observação

Para reconhecimento de voz e instalação PWA, HTTPS é recomendado/necessário em muitos navegadores. O backend pode continuar rodando em outro dispositivo/servidor.
