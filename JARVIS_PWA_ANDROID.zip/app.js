let backend = localStorage.getItem("jarvis_backend") || "http://127.0.0.1:8000";
let deferredInstall = null;
const chat = document.querySelector("#chat"), status = document.querySelector("#status");
const text = document.querySelector("#text");

function add(who,msg){
  const d=document.createElement("div"); d.className="msg "+who; d.textContent=msg;
  chat.appendChild(d); chat.scrollTop=chat.scrollHeight;
}
function say(msg){
  if("speechSynthesis" in window){
    speechSynthesis.cancel();
    const u=new SpeechSynthesisUtterance(msg); u.lang="pt-BR"; u.rate=.95;
    speechSynthesis.speak(u);
  }
}
function localCommand(s){
  const x=s.toLowerCase().trim();
  const open={
    "whatsapp":"https://wa.me/","youtube":"https://www.youtube.com/",
    "instagram":"https://www.instagram.com/","spotify":"https://open.spotify.com/",
    "tiktok":"https://www.tiktok.com/","chrome":"https://www.google.com/"
  };
  for(const [name,url] of Object.entries(open)){
    if((x.startsWith("abra ")||x.startsWith("abrir ")) && x.includes(name)){
      location.href=url; return true;
    }
  }
  const prefixes=["baixe ","baixar ","download "];
  for(const p of prefixes){
    if(x.startsWith(p)){
      const game=x.slice(p.length).trim();
      if(game){ location.href="https://play.google.com/store/search?q="+encodeURIComponent(game)+"&c=apps"; return true; }
    }
  }
  if(x.includes("abrir configurações")||x.includes("abrir configuracoes")){
    location.href="intent:#Intent;action=android.settings.SETTINGS;end"; return true;
  }
  return false;
}
async function send(msg){
  msg=msg.trim(); if(!msg)return;
  add("you",msg); status.textContent="Processando...";
  if(localCommand(msg)){status.textContent="Comando executado.";return;}
  try{
    const r=await fetch(backend.replace(/\/$/,"")+"/chat",{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:msg,conversation_id:"android-pwa"})
    });
    if(!r.ok) throw new Error();
    const data=await r.json(); const answer=data.message||"Não recebi uma resposta.";
    add("jarvis",answer); say(answer); status.textContent="Pronto.";
  }catch(e){
    const m="Não consegui conectar ao servidor do JARVIS. Verifique o endereço do backend.";
    add("jarvis",m); say(m); status.textContent="Servidor indisponível.";
  }
}
document.querySelector("#send").onclick=()=>{send(text.value);text.value=""};
text.addEventListener("keydown",e=>{if(e.key==="Enter"){document.querySelector("#send").click()}});
document.querySelector("#config").onclick=()=>{
  const v=prompt("Endereço do backend JARVIS:",backend);
  if(v){backend=v.trim();localStorage.setItem("jarvis_backend",backend);status.textContent="Servidor configurado."}
};
document.querySelector("#install").onclick=()=>{
  if(deferredInstall){deferredInstall.prompt();deferredInstall=null}
  else alert("No Chrome, abra o menu ⋮ e escolha 'Adicionar à tela inicial' ou 'Instalar app'.");
};
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e});
document.querySelector("#listen").onclick=()=>{
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){alert("Seu navegador não disponibilizou reconhecimento de voz. Use o Chrome.");return;}
  const r=new SR(); r.lang="pt-BR"; r.interimResults=false; r.maxAlternatives=1;
  status.textContent="🎙️ Ouvindo...";
  r.onresult=e=>{const msg=e.results[0][0].transcript;text.value=msg;send(msg);text.value=""};
  r.onerror=()=>status.textContent="Não consegui entender. Tente novamente.";
  r.onend=()=>{if(status.textContent==="🎙️ Ouvindo...")status.textContent="Pronto."};
  r.start();
};
if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
